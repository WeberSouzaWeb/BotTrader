package AV1;

import java.awt.BorderLayout;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Semaphore;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * 	SEMAFORO - 2 CLIENT - CAIXA POR CLIENT
 *  
 *  	MAXIMO 1000 OPERACOES
 *  
 *  @author Weber Souza
 */
public class Broker extends Thread {
	private Semaphore case1 = new Semaphore(2);     //caixa1
	// Ativo A = EURUSD
	private static final String AtivoA = "C:\\Users\\Weber Souza\\workspace\\AVANCADA_AV1_FINAL\\EURUSD_M30.csv";
	// Ativo B = USDCAD
	private static final String AtivoB = "C:\\Users\\Weber Souza\\workspace\\AVANCADA_AV1_FINAL\\USDCAD_M30.csv";
	// Ativo C = USDCNH
	private static final String AtivoC = "C:\\Users\\Weber Souza\\workspace\\AVANCADA_AV1_FINAL\\USDCNH_M30.csv";
	// Ativo D = USDJPY
	private static final String AtivoD = "C:\\Users\\Weber Souza\\workspace\\AVANCADA_AV1_FINAL\\USDJPY_M30.csv";

	// lista cria ativos 
	private static List<Active> actives = new LinkedList<Active>();
	public static  List<Double> atvA = new ArrayList<Double>();
	public static  List<String> timeA = new ArrayList<String>();
	public static  List<String> dateA = new ArrayList<String>();
	private static List<Double> atvB = new ArrayList<Double>();
	private static List<Double> atvC = new ArrayList<Double>();
	private static List<Double> atvD = new ArrayList<Double>();
	private static double[] lMMSVetor, mMMSVetor,sMMSVetor, MMEVetor, DPVetor, priceVetor;

	public static  Active A = new Active() ; 
	private static Active B = new Active(); 
	private static Active C = new Active(); 
	private static Active D = new Active(); 

	private int number_clients;						// numero de clientes	
	private static int fs;							//frequencia de amostragem 
	private int max_op;
	
	private Calculus cal;
	
	public static String date , time;
	public static double open,high,low,close,tick,pricE;
	
	private static List<Active> active = new LinkedList<Active>();
	private static List<Client> client = new LinkedList<Client>();
	private static List<Double> gCash = new ArrayList<Double>(); 				// LINKEDLIST< LINKEDLIST<STRING>> ID<A<TOTAL>>//
	
	
	// DINAMICA OPERA��O
	private int index;
	private boolean checkBuy;
	private boolean checkSell;
	private boolean check;						// Verifica se metodo de Atualizacao 
	private boolean endList;  					// Verifica se Lista Ativos esta vazia
	private long timestamp, jitter ;
	private double totalBuy;
	private double totalSell;

	private TimeSeries lMMS, mMMS,sMMS,  price;				// DINAMICA GRAFICA	MME, DP
	private TimeSeriesCollection dataset;
	

	public Broker(int fs) {//
		this.max_op = 1000;
		this.fs = fs;
		this.number_clients = 1;
		this.index = 0;
		
		
		A.readData(AtivoA);
		A.setName("EURUSD");
		B.readData(AtivoB);
		B.setName("USDCAD");
		C.readData(AtivoC);
		C.setName("USDCNH");
		D.readData(AtivoD);
		D.setName("USDJPY");

		
		actives.add(A);
		actives.add(B);
		actives.add(C);
		actives.add(D);
		
		cal = new Calculus(this,atvA);
		
				
		for(int i = 0;i<A.getClose().size();i++) {				// PEGAR TODO OS VALORES .CLOSE() -> atvA
			atvA.add(A.getClose().get(i));						// PARA O TEMPO E DATA DEVERIA FAZER O MESMO
			dateA.add(A.getDate().get(i));
			timeA.add(A.getTime().get(i));
		}
//		System.out.println(atvA.size());
		this.timestamp = new Date().getTime();
		System.out.println(timestamp+" Broker - 120 ");
		graphic();
		start();
				
//		System.out.println(A.getClose() +" Broker - 109");
//		this.active = list;
//		this.jitter = new Date().getTime();
//		System.out.println(jitter+" Broker - 130 ");
		createClient(number_clients, this, 10000.0);
//		this.jitter = new Date().getTime();
//		System.out.println(jitter+" Broker - 133 ");
		
	}

	public void run() {
		this.jitter = new Date().getTime();
		System.out.println(jitter+" Broker - 140 ");
		
		while(!check || !endList) {
			try {
				Thread.sleep(4);			// thread dorme 500 milisegundos
				
				Actualization();
				Trend();
				checkBuy = false;
				checkSell = false;
				
				
				timestamp = System.currentTimeMillis();
				System.out.println(timestamp+" Broker - 143 ");// LANCA COMPRAS E VENDAS 1662007795435
//				
				index++;					// VARIAVEL RESPONSAVEL PERCORRER
				
			}catch(InterruptedException exception) {
				exception.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
//********************* 	GERAL			****************************************** 
	public void geralCash(int Id, String Active, double operation ) throws IOException{
		try {
			if(checkBuy) {		//Verificar se � operacao de compra ou venda
				
				switch(Active){

				case "EURUSD":	gCash.add(Id, operation);
								client.get(Id).setA(atvA);//PASSAR ATIVO VALOR ADD 
				break; 
//				case "USDCAD": 	gCash.add(Id, A);
//								client.get(Id).setA(A);
//				break;
//				case "USDCNH": 	gCash.add(Id, A);
//								client.get(Id).setA(A);
//				break;
//				case "USDJPY": 	gCash.add(Id, A);
//								client.get(Id).setA(A);
//				break;			//lista<lista> - PRIMEIRO PASSO - ID - ATIVOS

				// verificar na lista de clientes o ID
				// pegar o valor do ativo e somar para o Client

				// AO CONTRARIO DO CASH DE CADA CLIENTE
				// O GERAL SALVA TODOS AS OPERA��ES
				}
			}else if(checkSell) {
				
				switch(Active){			// verificar na lista de clientes o ID
										// pegar o ativo e subtrair do Client

				case "EURUSD":	gCash.add(Id, atvA.get(index));
								client.get(Id).setA(atvA);
//				break; 
//				case "USDCAD": 	gCash.add(Id, A);
//								client.get(Id).setA(A);
//				break;
//				case "USDCNH": 	gCash.add(Id, A);
//								client.get(Id).setA(A);
//				break;
//				case "USDJPY": 	gCash.add(Id, A);
//								client.get(Id).setA(A);
				break;		}
				}
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	

	public void Actualization() throws InterruptedException {			// INCREMENTO DOS ATIVOS - DINAMICA REAL
		this.jitter = new Date().getTime();
		System.out.println(jitter+" Broker - 212 ");
		
		pricE = atvA.get(index);						// SEGUIMENTA NOS ATIVOS		
		// NAO TERIA QUE ADICIONAR O VALOR ESPECIFICO POR VEZ? 	
		sMMSVetor = new double [atvA.size()];
		sMMSVetor = cal.shortMM(index);

		mMMSVetor = new double [atvA.size()];
		mMMSVetor = cal.mediumMM(index);

		lMMSVetor = new double [atvA.size()];
		lMMSVetor = cal.longMM(index); //lMMSVetor[atvA.size()] = cal.longMM(index);

		MMEVetor = new double [atvA.size()];
			MMEVetor = cal.MME(1,index);
			
			DPVetor = new double [atvA.size()];
			DPVetor = cal.deviation(1, index);
///		}
		this.price.add(new Millisecond(), pricE);
		this.lMMS.add(new Millisecond(),lMMSVetor[index]);		// Adicionar no grafico o valor de retorno de calculus medias	
		System.out.println("index :"+index);
		this.mMMS.add(new Millisecond(),mMMSVetor[index]);
		this.sMMS.add(new Millisecond(),sMMSVetor[index]);
//		this.MME.add(new Millisecond(),pricE*0.9);
//		this.DP.add(new Millisecond(),0.5);
		this.jitter = new Date().getTime();
		System.out.println(jitter+" Broker - 239 ");
	}
	
	public void graphic() {
		
		
		this.price = new TimeSeries("Close", Millisecond.class);
		this.lMMS = new TimeSeries("LongMMS", Millisecond.class);
		this.mMMS = new TimeSeries("MediumMMS", Millisecond.class);
		this.sMMS = new TimeSeries("ShortMMS", Millisecond.class);
//		this.MME = new TimeSeries("Expo", Millisecond.class);
//		this.DP = new TimeSeries("DP", Millisecond.class);

		dataset = new TimeSeriesCollection();
		dataset.addSeries(price);
		dataset.addSeries(lMMS);							// ADICIONA OS VALORES DAS MEDIAS MOVEIS
		dataset.addSeries(mMMS);
		dataset.addSeries(sMMS);
//		dataset.addSeries(MME);
//		dataset.addSeries(DP);

		JFreeChart chart = ChartFactory.createTimeSeriesChart("Evoluation  Price ", "Time", "Price", dataset,
				true, true, false);

		XYPlot plot = chart.getXYPlot();
		ValueAxis x = plot.getDomainAxis();
		x.setAutoRange(true);
		x.setFixedAutoRange(72000.0); 						// 24 SEGUNDOS CORRESPONDEM A 1 DIA REAL
		x = plot.getRangeAxis();
		x.setRange(-1.0,5.0);


		ChartFrame frame1 = new ChartFrame("GRAPHIC EURUSD", chart);
		frame1.setVisible(true);
		frame1.setSize(1200,800);

//		System.out.println("Entrando Graphics");
		
	}

	//***********************			BUY / SELL					*****************************************    

	public void Buy(int idClient, String active, int qnt) throws IOException {				// metodo comprar
		try {
			case1.acquire();


			if(max_op != 0) {							//verifica operacao podem ser feitas
				switch(active){

				case "EURUSD":	System.out.println("Broker - A.getClose " + this.atvA.get(index));
								totalBuy = (atvA.get(index)*qnt);	// Compra ativo acessando o valor no momento
								time = timeA.get(index);
								System.out.println("Broker - time " + time);
								date = dateA.get(index);
								System.out.println("Broker - date " + date);
								geralCash(idClient, A.getName(),totalBuy);
				break; 
				case "USDCAD": 	totalBuy = (B.getClose().get(index)*qnt);
								time = B.getTime().get(index);
								date = B.getDate().get(index);
								geralCash(idClient, B.getName(),totalBuy);
				break;
				case "USDCNH": 	totalBuy = (C.getClose().get(index)*qnt);
								time = C.getTime().get(index);
								date = C.getDate().get(index);
								geralCash(idClient, C.getName(),totalBuy);
				break;
				case "USDJPY": 	totalBuy = (D.getClose().get(index)*qnt);
								time = D.getTime().get(index);
								date = D.getDate().get(index);
								geralCash(idClient, D.getName(),totalBuy);
				break;
				}
				checkBuy = true;
				max_op--;

				//addTiro(new Tiro());
				//System.out.printf("\n%s\n", "Compra: " + tiros.element().getId());
				//municao.pop();
			}	
			System.out.println("Operation NOT permitted ");			
		}catch(InterruptedException exception) {
			exception.printStackTrace();
		}
		finally {
			case1.release();									// desbloqueia esse objeto
		}
	}


	public void Sell(int idClient,String active, int qnt) throws IOException {
		try {
			case1.acquire();

			if(max_op != 0) {							//verifica operacao podem ser feitas
				switch(active){

				case "EURUSD":	System.out.println("Broker - Sell - Price: " + this.atvA.get(index));
								totalSell = (atvA.get(index)*qnt);	// Compra ativo acessando o valor no momento
								System.out.println("Total sell: " + this.totalSell);
								time = timeA.get(index);
								System.out.println("Broker - time " + time);
								date = dateA.get(index);
								System.out.println("Broker - date " + date);
								geralCash(idClient, A.getName(),totalSell);
				break; 
				case "USDCAD": 	totalSell = (B.getClose().get(index)*qnt);
								time = B.getTime().get(index);
								date = B.getDate().get(index);
								geralCash(idClient, B.getName(),totalSell);
				break;
				case "USDCNH": 	totalSell = (C.getClose().get(index)*qnt);
								time = C.getTime().get(index);
								date = C.getDate().get(index);
								geralCash(idClient, C.getName(),totalSell);
				break;
				case "USDJPY": 	totalSell = (D.getClose().get(index)*qnt);
								time = D.getTime().get(index);
								date = D.getDate().get(index);
								geralCash(idClient, D.getName(),totalSell);
				break;
				}
				checkSell = true;
				max_op--;
			}
			System.out.println("Operation NOT permitted ");	
		}catch(InterruptedException exception) {
			exception.printStackTrace();
		}
		finally {
			case1.release();									//desbloqueia esse objeto
		}
	}
	//*************************			CLIENT			*********************************************
	private void createClient(int number_client,Broker bkr, double cash) {
		// TODO Auto-generated method stub
		for(int count = 0; count < number_client; count++) {
			addClient(new Client(bkr,count, cash));
			gCash.add(count, 0.0);
		}
	}
	public double totalClient(int id) {
		if(client.get(id).getA()!=null) {
			double total = 0 ;
			for(int j = 0; j < client.get(id).getA().size(); j--) {
				total += client.get(id).getA().get(j); //actives.get(index).getClose().get(j-1); 
			}
		return total;
		}
		return 0;
	}

	
	public void addClient(Client block) {
		client.add(block);
	}public void removeClient(Client block) {
		client.remove(block);
	}public List<Client> getListClient(){
		return client;
	}
		  
	
//%%%%%%%%%%%%%%%%    TREND   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	

	public void Trend() throws IOException {  // COMPARAR MEDIAS COMPRADO VENDIDO
		if(sMMSVetor[index]>lMMSVetor[index] && sMMSVetor[index]>mMMSVetor[index]  ) {	//S>L & M>L & S>M
			if((((sMMSVetor[index] - mMMSVetor[index])/sMMSVetor[index])*100 > 2)&&
				(((sMMSVetor[index] - lMMSVetor[index])/sMMSVetor[index])*100 > 10)) {	// MULTIPLICAR DRAWDOWN
				for(int j = 0; j < client.size(); j++) {
					client.get(j).setBuy();
//					client.get(j).Buy(A.getName(),20);
				}
			}
		}else if(sMMSVetor[index]<lMMSVetor[index] && sMMSVetor[index]<mMMSVetor[index]  ) { //S>L & M>L & S>M
			if(((( mMMSVetor[index] - sMMSVetor[index])/mMMSVetor[index])*100 > 2)&&
					(((lMMSVetor[index] - sMMSVetor[index])/lMMSVetor[index])*100 > 10)) {	// MULTIPLICAR DRAWDOWN
				for(int j = 0; j < client.size(); j++) {
					client.get(j).setSell();
//					client.get(j).Sell(A.getName(),20);
				}
			}
		}
	}
	public void setCheckBuy() {
		this.checkBuy = true;
	}public void setCheckSell() {
		this.checkSell = true;
	}public double getTotalBuy() {
		return totalBuy;
	}public double getTotalSell() {
		return totalSell;
	}public static Active getA() {
		return A;
	}public static void setA(Active a) {
		A = a;
	}public static Active getB() {
		return B;
	}public static void setB(Active b) {
		B = b;
	}public static Active getC() {
		return C;
	}public static void setC(Active c) {
		C = c;
	}public static Active getD() {
		return D;
	}public static void setD(Active d) {
		D = d;
//	}public static LinkedList<Active> getActive() {
//		return active;
//	}public static void setActive(LinkedList<Active> active) {
//		Broker.active = active;
//	}public static LinkedList<Client> getClient() {
//		return client;
//	}public static void setClient(LinkedList<Client> client) {
//		Broker.client = client;
	}
}
