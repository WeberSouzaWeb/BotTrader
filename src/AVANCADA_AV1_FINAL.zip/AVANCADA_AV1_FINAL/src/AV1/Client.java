package AV1;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 *   COMPRA / VENDA - GATILHO
 *  
 *   DRAWDOWN - PRIORIDADE
 *  
 *   COMPRAR - VENDER : N�O COMPRAR - COMPRAR - VENDER
 *   
 *  MAX OPERAR - 30 
 * @author Weber Souza
 *
 */
public class Client extends Thread {
	private int fs,id;
	private boolean buy,sell;
	private double total;
        
    private double cash;    					// SALDO 
     private int operation;
    boolean checkA,checkB,checkC,checkD;
    
    private static Broker broker;
    private double[] wallet;
	private long timestamp, jitter;
    
    
    //public static LinkedList<Active> actives;
        
    // lista criar e gerir compras e vendas
    private static List<Double> A = new ArrayList<Double>();
    private static Active B = new Active();
    private static Active C = new Active();
    private static Active D = new Active();
    
//################################################################	
    public Client(Broker bkr,int id, double inicialCash) {
//    	this.timestamp = new Date().getTime();
//		System.out.println(timestamp+" Client - 46 ");
    	
    	this.fs = 30;
    	this.id = id;
    	this.operation = 3;
    	this.broker = bkr;
//    	this.actives = list;
    	this.cash = inicialCash;
    	
    	this.setPriority(NORM_PRIORITY);   	
    	
    	// SER� QUE PRECISO DE UMA LIST ZERADA????????? 
//    	list.get(0);
    	//SE PASSAR LIST QUE CRIEI NO BROKER TER� OS VALORES J� CARREGADOS
    	
    	start();
//    	this.jitter = new Date().getTime();
//		System.out.println(jitter+" Client - 63 ");
    }
        
  	public void run() {//inicializa o funcionamento da thread
//  		this.jitter = new Date().getTime();
//		System.out.println(jitter+" Client - 68 ");
  		while(true) {
  			try {
  				Thread.sleep(fs); 							// thread dorme 30 ms
//  				index++;
//  				System.out.println(this.isAlive());
  				
  				if(operation!=0) {
  					this.jitter = new Date().getTime();
  					System.out.println(jitter+" Client - 77 ");  					
  					Buy("EURUSD",20);
  					Sell("EURUSD",30);
  				}
  				
  				
  			}catch(InterruptedException exception) {
  				exception.printStackTrace();
  			} catch (IOException e) {
				e.printStackTrace();
			}
  		}
  	}
  	public void checkCash() {				// ATUALIZAR MINHA CARTEIRA		// Metodo para salvar todos os ativos "CARTEIRA"	
  					
  			System.out.println("Cash: "+this.cash);
  			System.out.println("----------------------**");
  	}
  	
//%%%%%%%%%%%%%%%%    BUY / SELL   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
  	
	public void Buy(String ativo, int qnt) throws IOException { // metodo de requisi�ao de compra 
		if(cash != 0 && buy) {operation--;					
			switch(ativo){
				
			case "EURUSD":	this.jitter = new Date().getTime();
							System.out.println(jitter+" Client - Buy - 102 ");
							broker.Buy(this.id, ativo, qnt); 	// COMO PEGAR O ULTIMO ELEMENTO DA LISTA DE ATIVO??????
							total = broker.getTotalBuy();	// QUAL VALOR DO PRECO??????
							this.cash = this.cash - total;	// SUBTRA��O DO CASH DO VALOR totalBuy
							checkCash();
							this.setPriority(MAX_PRIORITY);
							broker.setCheckBuy();			// HABILITA A CORRETORA SALVAR NO CASH GERAL		  			
							System.out.println("Client Buy: "+this.id);
			break; 
			
//			case "USDCAD": 	broker.Buy(this.id, B, qnt);
//							broker.setCheckBuy();
//			break;
//		    case "USDCNH": 	broker.Buy(this.id, C, qnt);
//		    				broker.setCheckBuy();
//			break;
//		    case "USDJPY": 	broker.Buy(this.id, D, qnt);
//		    				broker.setCheckBuy();
//			break;
			}
				   
		}else {
			System.out.println("Erro - Buy - Client "+this.id);
			this.jitter = new Date().getTime();
			System.out.println(jitter+" Client - 125 ");
	  } 
	  
	}
	public void Sell(String ativo, int qnt) throws IOException { // metodo de requisi�ao de compra
		if(cash != 0 && sell) {operation--;
			switch(ativo){
			
			case "EURUSD":	this.jitter = new Date().getTime();
							System.out.println(jitter+" Client - Sell - 136 ");
							broker.Sell(this.id, ativo, qnt); // COMO PEGAR O ULTIMO ELEMENTO DA LISTA DE ATIVO??????
							total = broker.getTotalSell();	// QUAL VALOR DO PRECO??????
							this.cash = this.cash + total;	// SOMA DO CASH DO VALOR totalSell
							checkCash();	
							this.setPriority(MAX_PRIORITY);
							broker.setCheckSell();
							System.out.println("Client Sell: "+this.id);
							
			break; 
//			case "USDCAD": 	broker.Sell(this.id, B, qnt);
//							broker.setCheckSell();
//			break;
//		    case "USDCNH": 	broker.Sell(this.id, C, qnt);
//		    				broker.setCheckSell();
//		    break;
//		    case "USDJPY": 	broker.Sell(this.id, D, qnt);
//	    					broker.setCheckSell();
//		    break;
			}
			// SOMAR DO CASH DO VALOR DE RETORNO totalSELL
				  
		}else {
			System.out.println("Erro - Sell - Client "+this.id);
			this.jitter = new Date().getTime();
			System.out.println(jitter+" Client - 154 ");
		} 
	  
	  } 

  //Get e Sets
	
  	public int getID() {
  		return id;
  	}public static List<Double> getA() {
		return A;
	}public static void setA(List<Double> double1) {
		A = double1;
	}public static Active getB() {
		return B;
	}public static void setB(Active b) {
		B = b;
	}public static Active getC() {
		return C;
	}public static void setC(Active c) {
		C = c;
	}public static Active getD() {
		return D;
	}public static void setD(Active d) {
		D = d;
	}public void setFS(int fs) {
  		this.fs = fs;
  	}public int getFS() {
  		return fs;
  	}public void setBuy() {
  		this.buy = true;
  	}public void setSell() {
  		this.sell = true;
  	}public double[] getWallet() {
  		return wallet;
  	}
}
