package AV1;


import java.util.LinkedList;
import java.util.List;

/**
 * MMS
 * MME
 * DESVIO PADRAO
 * CURTA  INTERMEDIARIA  LONGA
 * 
 *@author Weber Souza
 */
public class Calculus {
	private Broker broker;
	private int num;
	private double[] simple,exp,deviation;
	private double mms;
	
	
	private List<Double> actives;
		
//****************************************************************************************************** 	
	public Calculus(Broker b, List<Double> actives) {
		this.broker = b;
		this.actives =  actives;
		actives.addAll(b.atvA);
	}
			
/**
* @param period, index
*/
	public double[] MMS(int period, int index) { 				 // 1/ periodo * S (pre�o de fecha)
		num = actives.size();		//actives.get(index).getClose().size();
		simple = new double[num];
		for(int i = 0; i < num; i++) {
			if(i >= period) {
				double sum = 0;
				for(int j = i; j > i-period; j--) {
					sum += actives.get(j-1); //actives.get(index).getClose().get(j-1); 
				}
				simple[i] = (sum / period);
//				System.out.println(" MMS - "+simple[i]);
			}
		}
		return simple;
	}
	
	public double[] MME(int period, int index) {  // (pre�o de fecha *(2/(1+periodo))) + (MMS*(2/(1+periodo)
		double mult = 2/(1+period);
		int cont = period;
		
		double[] Aux = MMS(2,0);
		
		num = actives.size();			//actives.get(index).getClose().size();
		exp = new double[num];
		
		for(int j = (cont+1); j < num; j++) {
			exp[j] = (((actives.get(j))-Aux[j-cont])*mult)+Aux[j-cont];
		}
		return exp;
	}
	
	public double[] deviation(int periodo, int index) {
		num = actives.size();
		double soma;
		int aux = 0; 
		
		deviation = new double[num];
		simple = MMS(periodo, index);
		
		for(int i = periodo; i < simple.length; i++) {
			soma = 0;
			for(int j = aux; j < i; j++) {
				soma += (double) Math.pow(actives.get(j) - simple[i], 2);
			}
			deviation[i] = Math.sqrt(soma/(periodo - 1)); 
			aux++;
		}
		return deviation;
	}
	public double[] shortMM(int index) {    			//  passar um periodo de investiga��o  
		return MMS(14, index);
	}
	public double[] mediumMM(int index) {
		return MMS(50, index);
	}
	public double[] longMM(int index) {
		return MMS(200, index);
	}
}