package AV1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * INICIALIZACAO - CLASSES  
 *  
 * GRAFICOS TAMBEM SAO EXECUTADOS AQUI??? 
 * @author Weber Souza
 *
 */
public class Main {
	private static int fs;		
	private static Broker broker;
	private static Client client;
	
	//private FileWriter arq;
			//private CSVWriter gravarArq;

	public Main() {
		this.fs = 500;			// PERIODO 500 milissegundos

	}
//############## 		EXCEL		 ##################################################

	// public void Excel(String ativo) throws IOException { 
	//	  System.out.println("Csv - Salvando");
	//	  try {
	//	  arq = new FileWriter("./EXCEL/Salvo_"+ ativo +".xls"); 
	//	  gravarArq = new CSVWriter(arq);
	///		  
	//	  String[] header = {"Data","Hora","shortMMS","mediumMMS","longMMS", "MME", "DP"};
	//        String[] data;
	//        List<String[]> lista = new ArrayList<String[]>();
	//        lista.add(header);
	//	 
	//		 
	//        for (int i = 0; i < actives.size(); i++) {
	//               if (i < A.getClose().size()) { 				//largeMMS
	//
	//                  data = new String[]{actives.get(i).getDate().get(i),actives.get(i).getTime().get(i),
	//                  					String.valueOf(cal.shortMM(i)),String.valueOf(cal.mediumMM(i)),
	//                 					String.valueOf(cal.longMM(i)),String.valueOf(cal.MME(4, i)), String.valueOf(cal.deviation(4, i))};
	//                  lista.add(data);
	//             } else {
	//			
	/*
	 * if (i < MMAI.size()){ data = new
	 * String[]{datas.get(i),horas.get(i),String.valueOf(MMAL.get(MMAL.size()-1)),
	 * String.valueOf(MMAI.get(i)),String.valueOf(MMAC.get(i)),
	 * String.valueOf(MME.get(i)), String.valueOf(DP.get(i))}; lista.add(data); }
	 * else { if (i < MMAC.size()){ data = new
	 * String[]{datas.get(i),horas.get(i),String.valueOf(MMAL.get(MMAL.size()-1)),
	 * String.valueOf(MMAI.get(MMAI.size()-1)),String.valueOf(MMAC.get(i)),
	 * String.valueOf(MME.get(i)), String.valueOf(DP.get(DP.size()-1))};
	 * lista.add(data); } else { data = new
	 * String[]{datas.get(i),horas.get(i),String.valueOf(MMAL.get(MMAL.size()-1)),
	 * String.valueOf(MMAI.get(MMAI.size()-1)),String.valueOf(MMAC.get(MMAC.size()-1
	 * )), String.valueOf(MME.get(i)), String.valueOf(DP.get(DP.size()-1))};
	 * lista.add(data); } }
	 */

	//	                }
	//	            }
	//	            gravarArq.writeAll((Iterable<String[]>) lista);
	//	            gravarArq.close();
	//	            arq.close();


	//		  }catch (IOException e) { 
	//		  e.printStackTrace();
	//		  }
	//		  System.out.println("Fim");

	//	  }


	public static void main(String[] args) throws IOException {
		Main main = new Main();
		broker = new Broker(fs);
//		broker.getListClient().get(0).Buy("EURUDS",300);
//		System.out.println(" "+broker.getListClient().get(0).getID());
//		System.out.println(" "+broker.getListClient().get(0).isAlive());
//		System.out.println("Main compra:  "+broker.totalClient(0));
		//		System.out.println(AtivoA);

		
//		Broker bk = new Broker(fs,actives);
		
				
//		System.out.println(bk.getListClient().isEmpty());
//		System.out.println(bk.getListClient().get(0));
	}
}	
	
