package AV1;


import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;


/**
	 *  ATRIBUTOS - ATIVO
	 *  
	 *  ARRAYLIST - DADOS - CVS 
	 *  
	 *	@author Weber Souza
	 */
public class Active {
	
	
		private String name;
		private static List<String> date;					// data do valor do ativo lido
		private static List<String> time;					// horario do ativo 
		private static List<Double> open;
		private static List<Double> high;
		private static List<Double> low;
		private static List<Double> close;
		private static List<Double> tick;
		

		public Active() {
			date = new ArrayList<>();
			time = new ArrayList<>();
			open = new ArrayList<>();
			high = new ArrayList<>();
			low = new ArrayList<>();
			close = new ArrayList<>();
			tick = new ArrayList<>();
		}
	//#############  CSV  ###################################################
		public void readData(String file){
			try {  
				FileReader filereader = new FileReader(file);
				CSVParser parser = new CSVParserBuilder().withSeparator('\t').build();
				CSVReader csvReader = new CSVReaderBuilder(filereader).withCSVParser(parser).build();

				// Read all data at once
				List<List<String>> rows = new ArrayList<List<String>>();
				String[] column = null;
				csvReader.readNext();

				while ((column = csvReader.readNext()) != null) {
					rows.add(Arrays.asList(column));
				}

				rows.forEach(cols -> {
					date.add(cols.get(0));
					time.add(cols.get(1));
					open.add(Double.parseDouble(cols.get(2)));
					high.add(Double.parseDouble(cols.get(3)));
					low.add(Double.parseDouble(cols.get(4)));
					close.add(Double.parseDouble(cols.get(5)));
					tick.add(Double.parseDouble(cols.get(6)));
				});
				//System.out.println(rows);	            	
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		public  String getName() {
			return name;
		}public void setName(String name) {
			 this.name = name;
		}public static List<String> getDate() {
			return Collections.unmodifiableList(date);
		}public void setDate(List<String> d) {
			 this.date = d;
		}public static List<String> getTime() {
			return Collections.unmodifiableList(time);
		}public void setTime(List<String> t) {
			 this.time = t;
		}public static List<Double> getOpen() {
			return Collections.unmodifiableList(open);
		}public void setOpen(List<Double> op) {
			 this.open = op;
		}public static List<Double> getHigh() {
			return Collections.unmodifiableList(high);
		}public void setHigh(List<Double> h) {
			 this.high = h;
		}public static List<Double> getLow() {
			return Collections.unmodifiableList(low);
		}public void setLow(List<Double> l) {
			 this.low = l;
		}public static List<Double> getClose() {
			return Collections.unmodifiableList(close);
		}public void setClose(List<Double> c) {
			 this.close = c;
		}public static List<Double> getTick() {
			return Collections.unmodifiableList(tick);
		}
		
		
}
