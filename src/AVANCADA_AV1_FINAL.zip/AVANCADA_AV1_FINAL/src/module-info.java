module AVANCADA_AV1_FINAL {
	requires com.opencsv;
	requires jfreechart;
	requires java.desktop;
}